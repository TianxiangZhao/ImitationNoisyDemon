import os
import argparse

import ipdb
import numpy as np
import random
import math

def get_parser():
    parser = argparse.ArgumentParser()

    return parser
